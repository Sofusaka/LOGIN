import { Router } from "express";

import { UserLogin} from "../controller/controller.js";

//cambiar el nombre del endpoint

export const router = Router();

router.post("/login", UserLogin.LogIn)

