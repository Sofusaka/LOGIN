
export const APP_HOST = process.env.APP_HOST || "localhost";
export const APP_PORT = process.env.APP_PORT || 3000;
export const JWT_SECRET = process.env.JWT_SECRET || "O4Lq7xsaDE";