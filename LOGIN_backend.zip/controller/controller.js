import { JWT_SECRET } from "../config.js";
import jwt from "jsonwebtoken";

export class UserLogin{


  static async LogIn(req, res) {
    try {
      // Se obtienen el correo electrónico y la contraseña del cuerpo de la solicitud
      const { email, password } = req.body;
      console.log(req.body);
  
      // Se obtienen el correo electrónico y la contraseña almacenados en la base de datos
      const user_db = 'SofiaLinda'
      const password_db = 'Sofia123';
  
      // Se verifica si el correo electrónico y la contraseña coinciden con los de la base de datos
      if (
        email === user_db &&
        password===password_db
      ) {
        console.log("===================================================");
        console.log(
          `El usuario con correo ${email} inició sesión correctamente`
        );
  
        // Verificar si existe una clave secreta para JWT
        if (JWT_SECRET !== "") {
          // Generar token JWT
          const token = jwt.sign({email}, JWT_SECRET, {
            expiresIn: "1h",
          });
          // Devolver el token en la respuesta
          res.json({ token });
          console.log(`Token de inicio de sesión: ${token}`);
        } else {
          // Si no hay una clave secreta para JWT, enviar un mensaje de error
          res.status(500).json({ error: "No JWT_SECRET provided in ENV" });
        }
      } else {
        // Si las credenciales no coinciden, se devuelve un mensaje de error
        res.status(401).json({ error: "Invalid credentials" });
      }
    } catch (error) {
      // Manejar errores de manera adecuada
      console.error("Error during login:", error);
      res.status(500).json({ error: "An error occurred during login" });
    }
  }

  
}
